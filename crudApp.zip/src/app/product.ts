export class Product {
    id: number;
    productName: string;
    productPrice: string;
}
